//
//  SYSettingViewController.h
//  SYWristband
//
//  Created by obally on 17/5/15.
//  Copyright © 2017年 obally. All rights reserved.
//  设备管理

#import "SYBaseViewController.h"

@interface SYDeviveManagerViewController : SYBaseViewController

@end
