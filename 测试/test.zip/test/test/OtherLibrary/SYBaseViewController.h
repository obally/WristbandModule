//
//  SYBaseViewController.h
//  SYWristband
//
//  Created by obally on 17/5/11.
//  Copyright © 2017年 obally. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYBaseViewController : UIViewController

@end
