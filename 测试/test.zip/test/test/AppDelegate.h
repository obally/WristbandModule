//
//  AppDelegate.h
//  test
//
//  Created by obally on 2017/6/14.
//  Copyright © 2017年 obally. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

